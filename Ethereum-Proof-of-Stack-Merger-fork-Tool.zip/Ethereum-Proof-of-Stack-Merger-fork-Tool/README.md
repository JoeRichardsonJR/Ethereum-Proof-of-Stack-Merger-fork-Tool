Ethereum Proof of Stack Merger fork Tool

Feel free to fork and improve or whatever if you fork and modify please give credit
Simple JavaScript script that locks you into the merger and also forks your address.
By forking your ethereum address not only will you get the new Ethereum proof of stake but you were also get keep your Ethereum proof of work. 
And if the miners choose to continue which they already have signaled they are you will end up doubling you're holdings.
if by some chance the miners choose to not continue with the hard fork this will no way effect your ethereum holding. So it's basically a win-win
but hopefully for all of us they do hard fork and continue with both forks and we get to keep proof of work and proof of stake and double our wallet.
This has happened in the past with Bitcoin cash and Bitcoin. Anyone who held Bitcoin at the time of the hard fork also got equal amount of Bitcoin cash.


Let’s get started.

Part 1. Main software installations.

Extract the Ethereum-Proof-of-Stack-Merger-fork-Tool.zip anywhere you like that easy for you to find.

Part 2. Editing the settings.

Open the bots main folder and find "config.js" file and open it with a text-editor:

1.Set your public address and private key or your wallet seed if you have a wallet that does not give you the private key

3.Save config.js

4.Open index.html in any web-browser


Happy Forking :)
