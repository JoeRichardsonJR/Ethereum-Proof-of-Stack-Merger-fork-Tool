var myaddress = "your public address"
var myprivatekey = "your private key to the address"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
